<?xml version="1.0" encoding="UTF-8"?>
<FilteringTestSuiteEntity>
   <description></description>
   <name>Test API</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>53627398-34c6-4a03-a689-69a20f9129e4</testSuiteGuid>
   <filteringBuiltIn>com.kms.katalon.execution.platform.DynamicBuiltInSearch</filteringBuiltIn>
   <filteringExtension></filteringExtension>
   <filteringPlugin></filteringPlugin>
   <filteringText>id=(Test Cases) </filteringText>
</FilteringTestSuiteEntity>
